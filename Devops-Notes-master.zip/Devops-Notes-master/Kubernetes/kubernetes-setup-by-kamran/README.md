# learn-kubernetes
A repository to help learn kubernetes - mostly connected to the training videos of the same topic in Urdu - created by Kamran Azeem

**The related presentation is:** [here](https://docs.google.com/presentation/d/1WfshFCYPizcjeA-oBYV7l1JUezl75q8Jxd4IuXnilbs/edit?usp=sharing)
